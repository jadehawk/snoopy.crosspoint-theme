22 Snoopy and Woodstock sleep scenes, 44 compiled CPBs (X3 and larger portrait), 22 source PNGs.
This is an asset ZIP, not the installable theme.
Place the ZIP in snoopy.crosspoint-theme/source-art/; tools/build.py imports it.
The original sleep scene remains in both galleries.
